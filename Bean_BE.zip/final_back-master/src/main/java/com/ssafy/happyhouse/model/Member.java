package com.ssafy.happyhouse.model;

public class Member {
	String userid;
	String userpwd;
	String username;
	String userphone;
	String useradd;
	
	public String getUserid() { return userid; }
	public void setUserid(String userid) { this.userid = userid; }
	
	public String getUserpwd() { return userpwd; }
	public void setUserpwd(String userpwd) { this.userpwd = userpwd; }
	
	public String getUsername() { return username; }
	public void setUsername(String username) { this.username = username; }
	
	public String getUserphone() { return userphone; }
	public void setUserphone(String userphone) { this.userphone = userphone; }
	
	public String getUseradd() { return useradd; }
	public void setUseradd(String useradd) { this.useradd = useradd; }
}