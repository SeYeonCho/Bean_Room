package com.ssafy.happyhouse.model;

public class Favorite {
	String userid;
	int aptno;
	
	public String getUserid() { return userid; }
	public void setUserid(String userid) { this.userid = userid; }
	
	public int getAptno() { return aptno; }
	public void setAptno(int aptno) { this.aptno = aptno; }
	
}